<?php
session_start();
include '../../config.php';

// Function to sanitize input data
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}


if (isset($_POST["submit"])) {
    // Sanitize and retrieve form data
    $title = sanitizeInput($_POST['title']);
    $course_id = intval($_POST['course']); // Convert to integer
    $semester = sanitizeInput($_POST['semester']);
    $branch_id = $_SESSION['branch'];
    $exam_date = sanitizeInput($_POST['exam_date']);
    $start_time = sanitizeInput($_POST['start_time']);
    $end_time = sanitizeInput($_POST['end_time']);
    $subjects = $_POST['subjects']; // Array of subjects and their details

    // Validate required fields
    if (!empty($title) && !empty($course_id) && !empty($semester) && !empty($branch_id) && !empty($exam_date) && !empty($start_time) && !empty($end_time) && !empty($subjects)) {
        
        // Insert exam data
        $insert_exam_query = "INSERT INTO exams (title, course_id, semester, branch_id, exam_date, start_time, end_time) VALUES ('$title', $course_id, '$semester', $branch_id, '$exam_date', '$start_time', '$end_time')";
        $result_exam = $conn->query($insert_exam_query);

        if ($result_exam) {
            $exam_id = $conn->insert_id; // Get the ID of the inserted exam

            // Insert subjects data
            $insert_subject_query = "INSERT INTO subjects (exam_id, subject_name, min_marks, max_marks, semester) VALUES ";
            $value_strings = [];

            foreach ($subjects as $subject) {
                $subject_name = sanitizeInput($subject['name']);
                $min_marks = intval($subject['min_marks']); // Convert to integer
                $max_marks = intval($subject['max_marks']); // Convert to integer
                $subject_semester = sanitizeInput($subject['semester']);

                $value_strings[] = "($exam_id, '$subject_name', $min_marks, $max_marks, '$subject_semester')";
            }

            if (!empty($value_strings)) {
                $insert_subject_query .= implode(", ", $value_strings);
                $result_subject = $conn->query($insert_subject_query);

                if (!$result_subject) {
                    echo "Error inserting subjects: " . $conn->error;
                    exit();
                }
            }

            // Redirect to manage exams after successful insert
            header('Location: manage_exams.php');
            exit();
        } else {
            echo "Error inserting exam: " . $conn->error;
        }

    } else {
        echo "All fields are required.";
    }
}

// Query to retrieve courses and branches
$courses = $conn->query("SELECT * FROM tb_courses");
?>

<?php include "navbar.php"; ?>

<div class="container">
    <div class="card mt-5">
        <h5 class="card-header">Add Exam</h5>
        <div class="card-body">
            <h5 class="card-title">Add New Exam</h5>
            
            <form method="POST" action="#">
                <div class="mb-3">
                    <label for="title" class="form-label">Exam Title:</label>
                    <input type="text" id="title" name="title" class="form-control" required>
                </div>
                
                <div class="row">
                    <div class="mb-3 col-lg-6">
                        <label for="course">Course</label>
                        <select id="course_id" name="course" class="form-control" required>
                            <option value="">Select Course</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?= $course['id'] ?>"><?= $course['title'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3 col-lg-6">
                        <label for="semester">Semester</label>
                        <input type="text" id="semester" name="semester" class="form-control" required>
                    </div>
                </div>
                
                

                <div class="mb-3">
                    <label for="exam_date" class="form-label">Exam Date:</label>
                    <input type="date" id="exam_date" name="exam_date" class="form-control" required>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="start_time" class="form-label">Start Time:</label>
                        <input type="time" id="start_time" name="start_time" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="end_time" class="form-label">End Time:</label>
                        <input type="time" id="end_time" name="end_time" class="form-control" required>
                    </div>
                </div>

                <div id="subjectsContainer">
                    <!-- Subject fields will be added here dynamically -->
                </div>
                
                <button type="button" class="btn btn-success mt-3" id="addSubject">Add Subject</button>
                
                <button type="submit" class="btn btn-primary mt-4 float-end" name="submit">Add Exam</button>
            </form>
            <a href="../index.php" class="btn btn-outline-secondary mt-4">Back to Home</a>
        </div>
    </div>
</div>

<script>
document.getElementById('addSubject').addEventListener('click', function() {
    const subjectsContainer = document.getElementById('subjectsContainer');
    
    const subjectDiv = document.createElement('div');
    subjectDiv.classList.add('mb-4', 'subject-row', 'p-3', 'border', 'border-secondary', 'rounded');

    subjectDiv.innerHTML = `
        <div class="row">
            <div class="col-md-4">
                <label for="subject_name" class="form-label">Subject:</label>
                <input type="text" name="subjects[][name]" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label for="min_marks" class="form-label">Min Marks:</label>
                <input type="number" name="subjects[][min_marks]" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label for="max_marks" class="form-label">Max Marks:</label>
                <input type="number" name="subjects[][max_marks]" class="form-control" required>
            </div>

            <div class="col-md-2 d-flex align-items-end">
                <button type="button" class="btn btn-danger btn-sm removeSubject">Remove</button>
            </div>
        </div>
    `;

    subjectsContainer.appendChild(subjectDiv);

    subjectDiv.querySelector('.removeSubject').addEventListener('click', function() {
        subjectsContainer.removeChild(subjectDiv);
    });
});
</script>
