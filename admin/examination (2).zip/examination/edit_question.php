<?php
include "../../config.php";

if (isset($_POST['submit'])) {
    $question_number = $_POST['question_number'];
    $question_text = $_POST['question_text'];
    $correct_choice = $_POST['correct_choice'];
    $question_description = $_POST['description'];

    $choice = array();
    $choice[1] = $_POST['choice1'];
    $choice[2] = $_POST['choice2'];
    $choice[3] = $_POST['choice3'];
    $choice[4] = $_POST['choice4'];

    $query = "UPDATE questions SET question_text = '$question_text' , description = '$question_description' WHERE question_number = '$question_number'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $query = "DELETE FROM options WHERE question_number = '$question_number'";
        mysqli_query($conn, $query);

        foreach ($choice as $option => $value) {
            if ($value != "") {
                $is_correct = ($correct_choice == $option) ? 1 : 0;
                $query = "INSERT INTO options (question_number, is_correct, coption) VALUES ('$question_number', '$is_correct', '$value')";
                $insert_row = mysqli_query($conn, $query);

                if (!$insert_row) {
                    die("Option could not be inserted.");
                }
            }
        }
        $message = "Question has been updated successfully.";
        echo "<script>window.location.href='list_questions.php';</script>";
    }
}

if (isset($_GET['question_number'])) {
    $question_number = $_GET['question_number'];
    $query = "SELECT * FROM questions WHERE question_number = '$question_number'";
    $question_result = mysqli_query($conn, $query);

    if (mysqli_num_rows($question_result) == 1) {
        $question = mysqli_fetch_assoc($question_result);

        $query = "SELECT * FROM options WHERE question_number = '$question_number'";
        $options_result = mysqli_query($conn, $query);
        $choices = array();
        while ($option = mysqli_fetch_assoc($options_result)) {
            $choices[] = $option; // Store each option in $choices array
        }
    } else {
        // Handle case where question_number is invalid or not found
        die("Question not found.");
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <title>Edit Question</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
</head>
<body>
    <div class="container mt-5">
        <h1>Edit Question </h1>
        <div class="card mt-5">
            <div class="card-header">Edit Question</div>
            <div class="card-body">
                <?php if (isset($message)): ?>
                    <div class="alert alert-success" role="alert">
                        <?= $message ?>
                    </div>
                <?php endif; ?>

                <form action="edit_question.php" method="post">
                    <input type="hidden" name="question_number" value="<?= $question['question_number'] ?>">
                    <div class="mb-3">
                        <label for="question_text" class="form-label">Question Text:</label>
                        <input type="text" class="form-control" name="question_text" value="<?= $question['question_text'] ?>" required>
                    </div>

                    <?php foreach ($choices as $index => $choice): ?>
                        <div class="mb-3">
                            <label for="choice<?= $index + 1 ?>" class="form-label">Choice <?= $index + 1 ?>:</label>
                            <input type="text" class="form-control" name="choice<?= $index + 1 ?>" value="<?= $choice['coption'] ?>" required>
                        </div>
                    <?php endforeach; ?>
                    <div class="row">
                    <div class="mb-3 col-lg-2">
                                            <label for="correct_choice" class="form-label">Correct Option Number:</label>
                                            <input type="number" class="form-control" name="correct_choice" min="1" max="<?= count($choices) ?>" value="<?php 
                                                foreach ($choices as $key => $choice) {
                                                    if ($choice['is_correct']) echo $key + 1; // Display correct option index
                                                }
                                            ?>" required>
                                        </div>
                                        <div class="mb-3 col-lg-10">
                                            <label for="description" class="form-label">Description</label>
                                            <input type="text" class="form-control" name="description" value="<?= $question['description'] ?>">
                        </div>
                    </div>

                    <button type="submit" name="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>
