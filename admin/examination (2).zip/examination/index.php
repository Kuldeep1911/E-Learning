<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examination Portal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome to the Examination Portal</h1>
    <a href="add_exam.php">Add Exam</a> | <a href="manage_exams.php">Manage Exams</a>
</body>
</html>
