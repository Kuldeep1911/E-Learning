<?php
include "../../config.php";

// SQL query
$query = "
SELECT 
    q.question_number, 
    q.question_text, 
    GROUP_CONCAT(CONCAT(o.id, '. ', o.coption) ORDER BY o.id SEPARATOR ', ') AS options
FROM 
    questions q 
LEFT JOIN 
    options o 
ON 
    q.question_number = o.question_number 
GROUP BY 
    q.question_number, q.question_text;
";

// Execute the query
$questions = mysqli_query($conn, $query);

// Check for errors
if (!$questions) {
    die("Query Failed: " . mysqli_error($conn));
}

// Fetch all results into an array
$questionsArray = mysqli_fetch_all($questions, MYSQLI_ASSOC);
?>

<!doctype html>
<html lang="en">
    <head>
        <title>List Questions</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
        <style>
            /* Custom Styles */
            body {
                background-color: #f8f9fa;
            }
            .table-container {
                background: #ffffff;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                padding: 20px;
                border-radius: 8px;
            }
            table th {
                background-color: #007bff;
                color: white;
            }
            table tr:hover {
                background-color: #f1f1f1;
            }
            .btn-group {
                display: flex;
                gap: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container mt-5">
            <h2>Questions</h2>
            <div class="table-container">
                <table class="table table-hover table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Question Number</th>
                            <th>Question Text</th>
                            <th>Options</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($questionsArray as $row): ?>
                            <tr>
                                <td><?= $row['question_number'] ?></td>
                                <td><?= $row['question_text'] ?></td>
                                <td><?= $row['options'] ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="edit_question.php?question_number=<?= $row['question_number'] ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <a href="delete_question.php?question_number=<?= $row['question_number'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
    </body>
</html>
