<?php
session_start();
include "../../config.php";

// if (!isset($_SESSION['admin_id'])) {
//     header("Location: login.php");
//     exit();
// }

// Function to fetch all questions
function fetchQuestions($conn) {
    $query = "SELECT * FROM questions";
    $result = mysqli_query($conn, $query);
    return $result;
}

// Delete question functionality
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];

    // Delete from questions table
    $delete_query = "DELETE FROM questions WHERE id = $delete_id";
    $delete_result = mysqli_query($conn, $delete_query);

    // Delete from options table associated with the question
    $delete_options_query = "DELETE FROM options WHERE question_number = $delete_id";
    $delete_options_result = mysqli_query($conn, $delete_options_query);

    if ($delete_result && $delete_options_result) {
        $message = "Question deleted successfully.";
    } else {
        $error_message = "Failed to delete question.";
    }
}

// Fetch all questions
$questions = fetchQuestions($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="my-4">Manage Questions</h1>

        <?php if (isset($message)): ?>
            <div class="alert alert-success" role="alert">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger" role="alert">
                <?= $error_message ?>
            </div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Question Text</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($questions)): ?>
                    <tr>
                        <td><?= $row['question_number'] ?></td>
                        <td><?= $row['question_text'] ?></td>
                        <td>
                            <a href="edit_question.php?id=<?= $row['question_number'] ?>" class="btn btn-sm btn-primary">Edit</a>
                            <a href="?delete=<?= $row['question_number'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this question?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
