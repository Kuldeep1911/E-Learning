<?php
include "../../config.php";

// Ensure connection is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// Get the 'id' from the GET request
$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Prepare the SQL query to check if the id exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM exams WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    // Check if the id exists
    if ($count > 0) {
        // ID exists, do nothing or proceed with your logic
        $query = "SELECT * FROM questions WHERE exam_id = '$id'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            // Get the number of rows
            $question_count = mysqli_num_rows($result);

            // Calculate the next question number
            $next_question_number = $question_count + 1;

            // Output the next question number
            echo "The next question number for exam ID $id is: $next_question_number";
        } else {
            // Handle query failure
            echo "Error: " . mysqli_error($conn);
        }

    } else {
        // ID does not exist, redirect to exams.php
        echo "<script>window.location.href='exams.php';</script>";
        exit();
    }
} else {
    // If 'id' is not provided, redirect to exams.php
    echo "<script>window.location.href='exams.php';</script>";
    exit();
}

if (isset($_POST['submit'])) {
   
    $question_text = $_POST['question_text'];
    $correct_choice = $_POST['correct_choice'];
    $question_description = $_POST['description'];
    $exam_id = $_POST['exam_id'];

    // Choice array
    $choice = array();
    $choice[1] = $_POST['choice1'];
    $choice[2] = $_POST['choice2'];
    $choice[3] = $_POST['choice3'];
    $choice[4] = $_POST['choice4'];

    // Escape inputs to prevent SQL injection
    $question_text = mysqli_real_escape_string($conn, $question_text);
    $correct_choice = mysqli_real_escape_string($conn, $correct_choice);
    $question_description = mysqli_real_escape_string($conn, $question_description);
    $exam_id = mysqli_real_escape_string($conn, $exam_id);

    // First query for the question table
    $query = "INSERT INTO questions ( question_text , description ,exam_id) VALUES ( '$question_text' , '$question_description', '$exam_id')";

    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("1st query for question could not be executed: " . mysqli_error($conn));
    }

    if ($result) {
        foreach ($choice as $option => $value) {
            if ($value != "") {
                $is_correct = ($correct_choice == $option) ? 1 : 0;

                // Escape inputs to prevent SQL injection
                $value = mysqli_real_escape_string($conn, $value);

                // Second query for choice table
                $query = "INSERT INTO options ( is_correct, coption) VALUES ( '$is_correct', '$value')";

                // Debug: Output the query
                // echo "Query: $query<br>";

                $insert_row = mysqli_query($conn, $query);

                // Validate insert choice
                if (!$insert_row) {
                    die("2nd query for choice could not be executed: " . mysqli_error($conn));
                }
            }
        }
        $message = "Question has been added successfully.";
    }
}
// Fetch the Branch
$courses = $conn->query("SELECT * FROM subjects where exam_id='$id' ");
// Fetch the next question number
$query = "SELECT * FROM questions";
$questions = mysqli_query($conn, $query);
$total = mysqli_num_rows($questions);
$next = $total + 1;
?>


<!doctype html>
<html lang="en">
    <head>
        <title>Add Question</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />

        <!-- Custom Styles -->
        <!-- <link rel="stylesheet" href="styles.css"> -->
    </head>

    <body>
        <header>
            <!-- place navbar here -->
        </header>
        <main>
            <div class="container mt-5">
                <div class="card mt-5">
                    <div class="card-header">Add Question</div>
                    <div class="card-body">
                        <h5 class="card-title">Add New Question</h5>

                        <?php if (isset($message)): ?>
                            <div class="alert alert-success" role="alert">
                                <?=$message?>
                            </div>
                        <?php endif;?>

                        <form action="#" method="post">
                            <div class="row">
                                <div class="mb-3 col-lg-2">
                                    <label for="question_number" class="form-label">Question Number:</label><span  ><?php $next;?></span>
                                    <input type="number" class="form-control" name="question_number" value="<?php echo $next_question_number; ?>" readonly>
                                </div>
                                <div class="mb-3 col-lg-10">
                                <label for="c_id" class="form-label">Subject:</label>
                                <select id="c_id" name="exam_id" class="form-control" required>
                                    <option value="">Select Subject</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?=$course['id']?>"><?=$course['subject_name']?></option>
                                    <?php endforeach;?>
                                </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="question_text" class="form-label">Question Text:</label>
                                <input type="text" class="form-control" name="question_text" required>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-lg-6">
                                    <label for="choice1" class="form-label">Choice 1:</label>
                                    <input type="text" class="form-control" name="choice1" required>
                                </div>
                                <div class="mb-3 col-lg-6">
                                    <label for="choice2" class="form-label">Choice 2:</label>
                                    <input type="text" class="form-control" name="choice2" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="mb-3 col-lg-6">
                                    <label for="choice3" class="form-label">Choice 3:</label>
                                    <input type="text" class="form-control" name="choice3" required>
                                </div>
                                <div class="mb-3 col-lg-6">
                                    <label for="choice4" class="form-label">Choice 4:</label>
                                    <input type="text" class="form-control" name="choice4" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-lg-2">
                                    <label for="correct_choice" class="form-label">Correct Option Number:</label>
                                    <input type="number" class="form-control " name="correct_choice" min="1" max="4" required>
                                </div>
                                <div class="mb-3 col-lg-10">
                                <label for="description" class="form-label">Description</label>
                                <input type="text" class="form-control " name="description" min="1" max="4" >
                            </div>
                            </div>

                            <button type="submit" name="submit" class="btn btn-success">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <!-- place footer here -->
        </footer>
        <!-- Bootstrap JavaScript Libraries -->
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
