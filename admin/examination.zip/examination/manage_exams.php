<?php
session_start();
include '../../config.php';

// Delete operation: Delete exam
if (isset($_GET["delete"])) {
    $id = $_GET["delete"];

    // Delete exam data
    $query = $conn->prepare("DELETE FROM exams WHERE id=?");
    $query->bind_param("i", $id);
    $result = $query->execute();

    if ($result) {
        $_SESSION['message'] = "Exam deleted successfully.";
        $_SESSION['msg_type'] = "success";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $_SESSION['message'] = "Error deleting exam: " . $conn->error;
        $_SESSION['msg_type'] = "danger";
    }
   
}

// Update operation: Update exam details
if (isset($_POST['update'])) {
    $exam_id = $_POST['exam_id'];
    $title = $_POST['title'];
    // Add other fields for update here

    // Perform update query
    $query = $conn->prepare("UPDATE exams SET title=? WHERE id=?");
    $query->bind_param("si", $title, $exam_id);
    $result = $query->execute();

    if ($result) {
        $_SESSION['message'] = "Exam updated successfully.";
        $_SESSION['msg_type'] = "success";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $_SESSION['message'] = "Error updating exam: " . $conn->error;
        $_SESSION['msg_type'] = "danger";
    }
    
}

// Read operation: Fetch all exams
$exams = [];
$result = $conn->query("SELECT * FROM exams");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $exams[] = $row;
    }
} else {
    $_SESSION['message'] = "No exams found.";
    $_SESSION['msg_type'] = "info";
}

// Function to fetch course title based on course_id
function getCourseTitle($course_id) {
    global $conn;
    $result = $conn->query("SELECT title FROM tb_courses WHERE id = $course_id");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['title'];
    } else {
        return "N/A";
    }
}

// Function to fetch branch name based on branch_id
function getBranchName($branch_id) {
    global $conn;
    $result = $conn->query("SELECT branch_name FROM branches WHERE id = $branch_id");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['branch_name'];
    } else {
        return "N/A";
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Exams</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5 mb-3">Manage Exams</h2>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['msg_type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Exams Table -->
        <div class="card">
            <div class="card-header">
                Exams List
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Course</th>
                            <th>Semester</th>
                            <th>Branch</th>
                            <th>Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($exams as $exam): ?>
                            <tr>
                                <td><?php echo $exam['title']; ?></td>
                                <td><?php echo getCourseTitle($exam['course_id']); ?></td>
                                <td><?php echo $exam['semester']; ?></td>
                                <td><?php echo getBranchName($exam['branch_id']); ?></td>
                                <td><?php echo $exam['exam_date']; ?></td>
                                <td><?php echo $exam['start_time']; ?></td>
                                <td><?php echo $exam['end_time']; ?></td>
                                <td>
                                    <!-- Edit Button with Modal Trigger -->
                                    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#editExamModal<?php echo $exam['id']; ?>">Edit</button>
                                    <a href="?delete=<?php echo $exam['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this exam?')">Delete</a>
                                </td>
                            </tr>

                            <!-- Edit Exam Modal -->
                     <!-- Edit Exam Modal -->
                    <div class="modal fade" id="editExamModal<?php echo $exam['id']; ?>" tabindex="-1" aria-labelledby="editExamModalLabel<?php echo $exam['id']; ?>" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" style="max-width: 600px;">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editExamModalLabel<?php echo $exam['id']; ?>">Edit Exam</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form for editing exam details -->
                                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                                        <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                                        <div class="form-group">
                                            <label for="title">Title:</label>
                                            <input type="text" class="form-control" id="title" name="title" value="<?php echo $exam['title']; ?>">
                                        </div>
                                        <!-- Add other fields for editing here -->
                                        <div class="form-group">
                                            <label for="course_id">Course:</label>
                                            <select class="form-control" id="course_id" name="course_id">
                                                <?php
                                                $courses = $conn->query("SELECT id, title FROM tb_courses");
                                                while ($course = $courses->fetch_assoc()) {
                                                    $selected = ($course['id'] == $exam['course_id']) ? 'selected' : '';
                                                    echo '<option value="' . $course['id'] . '" ' . $selected . '>' . $course['title'] . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="semester">Semester:</label>
                                            <input type="text" class="form-control" id="semester" name="semester" value="<?php echo $exam['semester']; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="branch_id">Branch:</label>
                                            <select class="form-control" id="branch_id" name="branch_id">
                                                <?php
                                                $branches = $conn->query("SELECT id, branch_name FROM branches");
                                                while ($branch = $branches->fetch_assoc()) {
                                                    $selected = ($branch['id'] == $exam['branch_id']) ? 'selected' : '';
                                                    echo '<option value="' . $branch['id'] . '" ' . $selected . '>' . $branch['branch_name'] . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exam_date">Exam Date:</label>
                                            <input type="date" class="form-control" id="exam_date" name="exam_date" value="<?php echo $exam['exam_date']; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="start_time">Start Time:</label>
                                            <input type="time" class="form-control" id="start_time" name="start_time" value="<?php echo $exam['start_time']; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="end_time">End Time:</label>
                                            <input type="time" class="form-control" id="end_time" name="end_time" value="<?php echo $exam['end_time']; ?>">
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="update">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
