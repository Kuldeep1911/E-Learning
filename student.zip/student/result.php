<?php
include "../config.php";
session_start();

// Assume these values are provided by the session or form
$examId = $_SESSION['exam_id'];
$admitCardId = $_SESSION['admit_card_id'];

// Query to fetch user attempts and calculate score
$sql = "SELECT 
            COUNT(*) AS total_questions,
            SUM(is_correct) AS total_correct
        FROM 
            user_attempts
        WHERE 
            admit_card_id = ? AND exam_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $admitCardId, $examId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$total_questions = $row['total_questions'] ?: 0; // Avoid null, default to 0
$total_correct = $row['total_correct'] ?: 0; // Avoid null, default to 0

// Calculate score
$score = $total_questions > 0 ? ($total_correct / $total_questions) * 100 : 0;

// Unset session variables related to exam
unset($_SESSION['exam_id']);
unset($_SESSION['admit_card_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Results</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: radial-gradient(circle, rgba(238,174,202,1) 0%, rgba(148,187,233,1) 100%);
            animation: bgAnimation 10s infinite alternate;
        }
        @keyframes bgAnimation {
            0% { background-color: #ff9a9e; }
            100% { background-color: #fad0c4; }
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            position: relative;
            z-index: 1;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .score {
            font-size: 2.5rem;
            font-weight: bold;
            color: #28a745;
            animation: textPulse 1s infinite alternate;
        }
        @keyframes textPulse {
            from { color: #28a745; }
            to { color: #34ce57; }
        }
        .details {
            font-size: 1.2rem;
        }
        .fireworks {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="card-title">Congratulations!</h3>
                <p class="score"><?php echo round($score, 2); ?>%</p>
                <div class="details">
                    <p>Total Questions: <?php echo $total_questions; ?></p>
                    <p>Correct Answers: <?php echo $total_correct; ?></p>
                </div>
                <a href="index.php" class="btn btn-primary btn-block">Go to Dashboard</a>
            </div>
        </div>
    </div>
    <!-- Fireworks animation -->
    <canvas class="fireworks"></canvas>

    <script>
        const canvas = document.querySelector('.fireworks');
        const ctx = canvas.getContext('2d');
        const fireworks = [];

        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        class Firework {
            constructor() {
                this.reset();
            }
            reset() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.age = 0;
                this.color = `hsl(${Math.random() * 360}, 100%, 50%)`;
            }
            update() {
                this.age++;
                if (this.age > 100) this.reset();
            }
            draw() {
                ctx.fillStyle = this.color;
                ctx.beginPath();
                ctx.arc(this.x, this.y, Math.sin(this.age / 100 * Math.PI) * 10, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        for (let i = 0; i < 50; i++) {
            fireworks.push(new Firework());
        }

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (let firework of fireworks) {
                firework.update();
                firework.draw();
            }
            requestAnimationFrame(animate);
        }

        animate();
    </script>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
